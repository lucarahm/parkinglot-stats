This project has the following team members:
- Simon Draxl
- Luca Rahm
- Evin Aydin
- Alexander Montag

The dataset used can be found at: https://www.kaggle.com/datasets/ammarnassanalhajali/pklot-dataset
(accessed 25.01.2024)

Included in the submission is also the zip file we used as a layer for the createAndStorePlot lambda function, as this requires the matplotlib package
